/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;
import Gui.form_login;

/**
 *
 * a
 */
public class SistemInformasiAdministrasiDanRekamMedisPasienKlinik {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        form_login fl = new form_login();
        fl.show();
       
    }
    
}
